#!/bin/bash
# 🔴 EKSTREM BUILD SCRIPT

echo "🔴🔴🔴 Building MATRYOSHKA APK - EKSTREM EDITION 🔴🔴🔴"

# Generate keystore if not exists
if [ ! -f system.keystore ]; then
    echo "Generating keystore..."
    keytool -genkey -v -keystore system.keystore \
        -alias system -keyalg RSA -keysize 2048 \
        -validity 10000 -storepass android15_ekstrem \
        -keypass android15_ekstrem \
        -dname "CN=System, OU=Core, O=Android, L=System, S=System, C=US"
fi

# Clean
echo "Cleaning..."
./gradlew clean

# Build Release
echo "Building APK..."
./gradlew assembleRelease

# Sign (already signed in build.gradle)
echo "Signing completed"

# Optimize
echo "Optimizing APK..."
zipalign -v -p 4 app/build/outputs/apk/release/app-release.apk app/build/outputs/apk/release/app-release-aligned.apk

# Verify
echo "Verifying signature..."
apksigner verify app/build/outputs/apk/release/app-release-aligned.apk

# Rename with timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
mv app/build/outputs/apk/release/app-release-aligned.apk "Matryoshka_v6.0_${TIMESTAMP}.apk"

echo "✅ BUILD COMPLETE!"
echo "📱 APK: Matryoshka_v6.0_${TIMESTAMP}.apk"
echo "🔴🔴🔴 READY TO DEPLOY 🔴🔴🔴"