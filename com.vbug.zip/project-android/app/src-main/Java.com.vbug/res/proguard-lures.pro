# 🔴 MAXIMUM OBFUSCATION - EVASION RULES
-dontwarn
-dontnote
-optimizationpasses 7
-overloadaggressively
-repackageclasses 'a'
-allowaccessmodification
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontskipnonpubliclibraryclassmembers
-verbose
-dontpreverify

# Remove logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# Keep only essential
-keep class com.android.system.update.MainActivity { *; }
-keep class * implements android.os.Parcelable { *; }
-keepclassmembers class * implements java.io.Serializable { *; }

# Flatten package
-flattenpackagehierarchy 'a'

# Merge interfaces
-mergeinterfacesaggressively