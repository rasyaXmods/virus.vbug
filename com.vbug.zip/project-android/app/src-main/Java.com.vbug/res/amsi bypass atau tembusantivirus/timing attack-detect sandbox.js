// 🔴 Sandbox Detection via Timing
public class SandboxDetector {
    
    public static boolean isSandbox() {
        // Cek kecepatan eksekusi
        long start = System.nanoTime();
        for (int i = 0; i < 1000000; i++) {
            Math.sqrt(i);
        }
        long duration = System.nanoTime() - start;
        
        // Sandbox biasanya lebih lambat atau lebih cepat
        if (duration < 5000000 || duration > 50000000) {
            return true;
        }
        
        // Cek human interaction
        long lastUserActivity = getLastUserActivity();
        if (System.currentTimeMillis() - lastUserActivity > 300000) {
            return true; // No user activity for 5 minutes
        }
        
        return false;
    }
    
    private static long getLastUserActivity() {
        try {
            Class<?> activityManager = Class.forName("android.app.ActivityManager");
            Method getLastUserActivity = activityManager.getMethod("getLastUserActivityTime");
            return (long) getLastUserActivity.invoke(null);
        } catch (Exception e) {
            return System.currentTimeMillis();
        }
    }
}