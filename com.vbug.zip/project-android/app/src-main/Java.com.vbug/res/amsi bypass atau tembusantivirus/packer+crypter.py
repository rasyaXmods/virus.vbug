# 🔴 Matryoshka Packer - 5 Layer Encryption
import base64
import zlib
import random
from Crypto.Cipher import AES, ChaCha20
import hashlib

class MatryoshkaPacker:
    def __init__(self, payload):
        self.payload = payload
        self.layers = [
            self.layer1_xor,
            self.layer2_aes,
            self.layer3_chacha20,
            self.layer4_compress,
            self.layer5_base64
        ]
    
    def pack(self):
        data = self.payload.encode()
        keys = []
        
        for i, layer in enumerate(self.layers):
            data, key = layer(data)
            keys.append(key)
            print(f"🔴 Layer {i+1} applied")
        
        return data, keys
    
    def layer1_xor(self, data):
        key = random.randint(1, 255)
        result = bytes([b ^ key for b in data])
        return result, key
    
    def layer2_aes(self, data):
        key = hashlib.sha256(str(random.random()).encode()).digest()
        cipher = AES.new(key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        result = cipher.nonce + tag + ciphertext
        return result, key
    
    def layer3_chacha20(self, data):
        key = hashlib.sha256(str(random.random()).encode()).digest()
        nonce = hashlib.md5(str(random.random()).encode()).digest()
        cipher = ChaCha20.new(key=key, nonce=nonce)
        result = nonce + cipher.encrypt(data)
        return result, key
    
    def layer4_compress(self, data):
        result = zlib.compress(data, level=9)
        return result, None
    
    def layer5_base64(self, data):
        result = base64.b64encode(data)
        return result, None